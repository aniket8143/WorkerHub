package com.app.entity;

public enum Role {
	
	ADMIN, USER

}



